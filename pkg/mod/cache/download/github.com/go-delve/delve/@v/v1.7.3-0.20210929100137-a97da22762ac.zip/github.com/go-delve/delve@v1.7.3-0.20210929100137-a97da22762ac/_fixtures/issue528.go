package main

import (
	"fmt"
	"github.com/peterh/liner"
)

func main() {
	line := liner.NewLiner()
	line.Close()
	fmt.Printf("test\n")
}
